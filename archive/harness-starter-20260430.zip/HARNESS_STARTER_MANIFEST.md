# Harness Starter Archive

Created: 2026-04-30
Source task: TASK-20260430-007

## Included
- Harness authority documents: AGENTS.md, ARCHITECTURE.md, SECURITY.md, CLAUDE.md, QUALITY_SCORE.md
- Harness operation/workflow/schema/agent documentation under docs/
- Generic harness guide documents under docs/guides/
- Harness automation scripts under scripts/
- package.json script entrypoints
- .gitignore and .editorconfig
- reports/TASK-EXAMPLE.md
- Empty starter directories: logs/tasks, logs/sessions, reports, tasks/specs, tasks/handoffs, tasks/fixtures

## Excluded
- LandinHub web service implementation: api/, public/, wrangler.toml
- LandinHub runtime outputs/assets: download/, archive/quotes.html, docs/plans/, docs/img/
- LandinHub README and current project state: README.md, CURRENT_STATE.md
- Local/runtime/secret files: .env, .env.*, .dev.vars, .wrangler/, .claude/, .playwright-mcp/, credentials.*, secrets.*
- Historical task ledgers, handoffs, reports, and session logs from this repository

## Normalized
- Text copies inside this archive replace project-specific landinghub naming with generic harness naming where it appeared in harness documents.

## New Project Setup Notes
1. Extract this archive into a new repository root.
2. Create a fresh CURRENT_STATE.md for that project before the first reentry workflow.
3. Keep .env/.dev.vars out of git and use secret stores for tokens and credentials.
4. Replace schema IDs or product-specific examples if the new project needs different naming.